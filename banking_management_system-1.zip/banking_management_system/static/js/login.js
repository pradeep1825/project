/* =========================================================
   login.js
   Handles form validation + submission for Customer Login
   ========================================================= */

document.getElementById("loginForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    document.getElementById("email_error").textContent = "";
    document.getElementById("password_error").textContent = "";

    let isValid = true;

    if (!isValidEmail(email)) {
        document.getElementById("email_error").textContent = "Enter a valid email address.";
        isValid = false;
    }
    if (password.length === 0) {
        document.getElementById("password_error").textContent = "Password is required.";
        isValid = false;
    }

    if (!isValid) return;

    const result = await callApi("/api/login", "POST", { email, password });

    if (result.data.success) {
        showMessage("formMessage", result.data.message, "success");
        setTimeout(() => { window.location.href = "/dashboard"; }, 800);
    } else {
        showMessage("formMessage", result.data.message, "error");
    }
});
