/* =========================================================
   deposit.js
   Handles the Deposit Money form
   ========================================================= */

document.getElementById("depositForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const accountNumber = document.getElementById("account_number").value.trim();
    const amount = document.getElementById("amount").value;

    document.getElementById("account_number_error").textContent = "";
    document.getElementById("amount_error").textContent = "";

    let isValid = true;
    if (accountNumber.length === 0) {
        document.getElementById("account_number_error").textContent = "Account number is required.";
        isValid = false;
    }
    if (!amount || Number(amount) <= 0) {
        document.getElementById("amount_error").textContent = "Enter a valid amount greater than 0.";
        isValid = false;
    }
    if (!isValid) return;

    const result = await callApi("/api/deposit", "POST", {
        account_number: accountNumber,
        amount: Number(amount)
    });

    if (result.data.success) {
        showMessage("formMessage",
            `${result.data.message} New Balance: ₹${formatMoney(result.data.new_balance)}`, "success");
        document.getElementById("depositForm").reset();
    } else {
        showMessage("formMessage", result.data.message, "error");
    }
});
