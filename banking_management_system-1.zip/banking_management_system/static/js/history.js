/* =========================================================
   history.js
   Loads balance + transaction history for a given account number
   ========================================================= */

document.getElementById("lookupForm").addEventListener("submit", async function (e) {
    e.preventDefault();
    const accountNumber = document.getElementById("account_number").value.trim();
    if (!accountNumber) return;

    // 1. Get current balance
    const balanceResult = await callApi(`/api/balance/${accountNumber}`, "GET");
    const balanceBox = document.getElementById("balanceDisplay");

    if (!balanceResult.data.success) {
        balanceBox.innerHTML = "";
        showMessage("formMessage", balanceResult.data.message, "error");
        document.getElementById("historyTableBody").innerHTML = "";
        return;
    }
    showMessage("formMessage", "", "success");
    document.getElementById("formMessage").style.display = "none";

    balanceBox.innerHTML = `Current Balance: <strong>₹ ${formatMoney(balanceResult.data.balance)}</strong>`;

    // 2. Get transaction history
    const historyResult = await callApi(`/api/transactions/${accountNumber}`, "GET");
    const tbody = document.getElementById("historyTableBody");
    tbody.innerHTML = "";

    if (!historyResult.data.success || historyResult.data.transactions.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="empty-state">No transactions yet.</td></tr>`;
        return;
    }

    historyResult.data.transactions.forEach(tx => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${tx.transaction_date}</td>
            <td class="type-${tx.transaction_type.toLowerCase()}">${tx.transaction_type.replace("_", " ")}</td>
            <td>₹ ${formatMoney(tx.amount)}</td>
            <td>₹ ${formatMoney(tx.balance_after)}</td>
            <td>${tx.related_account ? tx.related_account : "-"}</td>
        `;
        tbody.appendChild(row);
    });
});
