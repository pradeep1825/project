/* =========================================================
   register.js
   Handles form validation + submission for Customer Registration
   ========================================================= */

document.getElementById("registerForm").addEventListener("submit", async function (e) {
    e.preventDefault(); // stop normal HTML form submission

    // ----- Read values -----
    const fullName = document.getElementById("full_name").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm_password").value;

    // ----- Clear old errors -----
    ["full_name", "email", "phone", "password", "confirm_password"].forEach(id => {
        document.getElementById(id + "_error").textContent = "";
    });

    let isValid = true;

    // ----- Frontend Validation -----
    if (fullName.length < 3) {
        document.getElementById("full_name_error").textContent = "Name must be at least 3 characters.";
        isValid = false;
    }
    if (!isValidEmail(email)) {
        document.getElementById("email_error").textContent = "Enter a valid email address.";
        isValid = false;
    }
    if (!isValidPhone(phone)) {
        document.getElementById("phone_error").textContent = "Phone must be exactly 10 digits.";
        isValid = false;
    }
    if (password.length < 6) {
        document.getElementById("password_error").textContent = "Password must be at least 6 characters.";
        isValid = false;
    }
    if (password !== confirmPassword) {
        document.getElementById("confirm_password_error").textContent = "Passwords do not match.";
        isValid = false;
    }

    if (!isValid) return; // stop here if validation failed

    // ----- Send data to Flask backend -----
    const result = await callApi("/api/register", "POST", {
        full_name: fullName,
        email: email,
        phone: phone,
        password: password
    });

    if (result.data.success) {
        showMessage("formMessage", result.data.message, "success");
        setTimeout(() => { window.location.href = "/login"; }, 1200);
    } else {
        showMessage("formMessage", result.data.message, "error");
    }
});
