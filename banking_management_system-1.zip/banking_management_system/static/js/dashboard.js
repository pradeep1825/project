/* =========================================================
   dashboard.js
   Loads the customer's accounts and handles "Create Account"
   ========================================================= */

// Load accounts as soon as the dashboard page opens
document.addEventListener("DOMContentLoaded", loadAccounts);

async function loadAccounts() {
    const result = await callApi("/api/accounts", "GET");
    const grid = document.getElementById("accountsGrid");
    grid.innerHTML = "";

    if (!result.data.success || result.data.accounts.length === 0) {
        grid.innerHTML = `<div class="empty-state">
            You don't have any bank account yet. Click "Create New Account" to open one.
        </div>`;
        return;
    }

    result.data.accounts.forEach(acc => {
        const card = document.createElement("div");
        card.className = "account-card";
        card.innerHTML = `
            <div class="acc-number">A/C No: ${acc.account_number}</div>
            <div class="acc-balance">₹ ${formatMoney(acc.balance)}</div>
            <div class="acc-type">${acc.account_type} Account</div>
        `;
        grid.appendChild(card);
    });
}

// Handle "Create New Account" form submit
document.getElementById("createAccountForm").addEventListener("submit", async function (e) {
    e.preventDefault();
    const accountType = document.getElementById("account_type").value;

    const result = await callApi("/api/create_account", "POST", { account_type: accountType });

    if (result.data.success) {
        showMessage("createMessage", `Account created! Account Number: ${result.data.account_number}`, "success");
        document.getElementById("createAccountModal").style.display = "none";
        loadAccounts();
    } else {
        showMessage("createMessage", result.data.message, "error");
    }
});

function openCreateAccountModal() {
    document.getElementById("createAccountModal").style.display = "flex";
}

function closeCreateAccountModal() {
    document.getElementById("createAccountModal").style.display = "none";
}
