/* =========================================================
   common.js
   Shared helper functions used on every page.
   TELUGU: Ee functions anni pages lo common ga use avutayi.
   ========================================================= */

// Show a message box (success or error) on the page
function showMessage(elementId, text, type) {
    const box = document.getElementById(elementId);
    if (!box) return;
    box.textContent = text;
    box.className = "message-box " + (type === "success" ? "message-success" : "message-error");
}

// Generic helper to call our Flask JSON APIs
async function callApi(url, method = "GET", body = null) {
    const options = {
        method: method,
        headers: { "Content-Type": "application/json" }
    };
    if (body) {
        options.body = JSON.stringify(body);
    }
    const response = await fetch(url, options);
    const data = await response.json();
    return { status: response.status, data };
}

// Logout button handler (used in navbar on every logged-in page)
async function logout() {
    const result = await callApi("/api/logout", "POST");
    if (result.data.success) {
        window.location.href = "/login";
    }
}

// Simple email format check
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Simple 10-digit phone check
function isValidPhone(phone) {
    return /^[0-9]{10}$/.test(phone);
}

// Format numbers as currency, e.g. 1000 -> "1,000.00"
function formatMoney(amount) {
    return Number(amount).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
