/* =========================================================
   transfer.js
   Handles the Fund Transfer form
   ========================================================= */

document.getElementById("transferForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const fromAccount = document.getElementById("from_account").value.trim();
    const toAccount = document.getElementById("to_account").value.trim();
    const amount = document.getElementById("amount").value;

    ["from_account_error", "to_account_error", "amount_error"].forEach(id => {
        document.getElementById(id).textContent = "";
    });

    let isValid = true;
    if (fromAccount.length === 0) {
        document.getElementById("from_account_error").textContent = "Sender account number is required.";
        isValid = false;
    }
    if (toAccount.length === 0) {
        document.getElementById("to_account_error").textContent = "Receiver account number is required.";
        isValid = false;
    }
    if (fromAccount && toAccount && fromAccount === toAccount) {
        document.getElementById("to_account_error").textContent = "Cannot transfer to the same account.";
        isValid = false;
    }
    if (!amount || Number(amount) <= 0) {
        document.getElementById("amount_error").textContent = "Enter a valid amount greater than 0.";
        isValid = false;
    }
    if (!isValid) return;

    const result = await callApi("/api/transfer", "POST", {
        from_account: fromAccount,
        to_account: toAccount,
        amount: Number(amount)
    });

    if (result.data.success) {
        showMessage("formMessage",
            `${result.data.message} Remaining Balance: ₹${formatMoney(result.data.new_balance)}`, "success");
        document.getElementById("transferForm").reset();
    } else {
        showMessage("formMessage", result.data.message, "error");
    }
});
